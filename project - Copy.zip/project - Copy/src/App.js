import './App.css';
import User_block from './components/User_block/User_block';
import Central_block from './components/Central_block/Central_block';
import Footer from './components/Footer/Footer';
import Friend_block from './components/Friend_block/Friend_block';


const App = (props) => {

  
  return (
    <div className="body ">
        <div className="grid">
          <User_block />
          <Friend_block state={props.statefriend}/>
          <Central_block  state={props.state}/>
          {/* <Footer /> */}
        </div>
    </div>
  );
}

export default App;
