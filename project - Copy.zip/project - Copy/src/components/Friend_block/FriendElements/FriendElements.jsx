import stayl from './FriendElements.module.css';


const FriendElements = (props) => {
  return (
    <div className={stayl.wrapper}>
      <div className={stayl.friend__photo}>
        <img src="https://i.pinimg.com/originals/98/2b/01/982b012530231e444573cc35bdeed3cd.jpg" alt="" />
      </div>
      <div className={stayl.name}>
          <a href="#">{props.name}</a>
      </div>
    </div>
  );
}


export default FriendElements;