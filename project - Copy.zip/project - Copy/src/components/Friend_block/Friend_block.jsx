import style from './Friend_block.module.css';
import FriendElements from './FriendElements/FriendElements'




const Friend_block = (props) => {
  let Friend = props.state.map ( statefriend =>  <FriendElements statefriend={statefriend.name}/>);

  return (
    <section className={style.section}>
      <div className={style.wrapper}>
        <a href="#"><h2>Friends</h2></a>
        <div className={style.friend}>
          {Friend}
        </div>
      </div>
    </section>
  );
}


export default Friend_block;