import './User_block.css';

const User_block = () => {
  return ( 
      <section className="grid_box grid_1">
        <div className="grid_container grid_container_1">
          <img className="image_user"src="https://scontent-iev1-1.cdninstagram.com/v/t51.2885-19/s320x320/154831923_118691653531982_1654043460584796627_n.jpg?tp=1&_nc_ht=scontent-iev1-1.cdninstagram.com&_nc_ohc=YYT5A1ayD8EAX98JlWO&ccb=7-4&oh=3c3b483cd671e5dc048470d2148f1782&oe=6086D4C4&_nc_sid=7bff83" alt="loading..." />
          <h1 name="user_name" className="user_name">Костецкий Олег</h1>
          {/* <ul className="user_information">
              <li>Date of Birth:<p>6 Aprille</p></li>
              <li>City:<p>Kherson</p></li>
              <li>Education:<p>-</p></li>
              <li>Web Site:<p>-</p></li>
            </ul> */}
        </div>
      </section>
	);
}


export default User_block;