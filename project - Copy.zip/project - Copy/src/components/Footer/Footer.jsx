import './Footer.css';

const Footer = () => {
  return ( 
      <footer className="grid_box grid_5">
        <div className="grid_container grid_container_5"></div>
      </footer>
	);
}


export default Footer;