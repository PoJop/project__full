import { NavLink } from 'react-router-dom';
import style from './Dialogs.module.css';
import Message from './Massage/Message';
import Interlocutor from './Interlocutor/Interlocutor';
import MassageInterlocutor from './MassageInterlocutor/MassageInterlocutor';


const Dialogs = (props) => {



  let dialogsElements = props.dialogsDate.map ( dialog =>  <Interlocutor name={dialog.name} id={dialog.id} />);


  let messageElementsUser = props.messageDate.map ( message =>  <Message message={message.message}/>);
  let messageElementsInterlocutor = props.messageDate.map ( message =>  <MassageInterlocutor message={message.message}/>);
  return (
    <main className="grid_container grid_container_4" >
      <div className="main_background">
        <div className={style.container}>
          <div className={style.contacts}>
            { dialogsElements }
          </div>
          <hr />
          <div className={style.dialogs}>
            <div className={style.massage_container}>
            { messageElementsUser }
            { messageElementsInterlocutor }
            </div>
            <div className={style.typing}>
              <textarea className={style.textarea}></textarea>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}


export default Dialogs;