import style from './Message.module.css';

const Message = (props) => {
  return (
  <div className={style.massage_box}>
    <div className={style.massage}>{props.message}</div>
  </div>
  );
}


export default Message;