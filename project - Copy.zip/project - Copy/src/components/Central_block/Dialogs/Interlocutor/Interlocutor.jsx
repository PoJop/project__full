import { NavLink } from 'react-router-dom';
import style from './Interlocutor.module.css';

const Interlocutor = (props) => {
  return (
    <NavLink to={"/messages/" + props.id}>
      <div className={style.container}>
        <div className={style.status}>
          <div className={style.div}></div>
        </div>
        <div className={style.name}>
          {props.name}
        </div>
      </div>
      <hr className={style.hr} />
    </NavLink>
  );
}


export default Interlocutor;