import './Music.css';

const Music = () => {
  return (
    <main className="grid_container grid_container_4">
      <div className="main_background">

      </div>
    </main>
  );
}


export default Music;