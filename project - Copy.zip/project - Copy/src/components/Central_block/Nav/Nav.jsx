import { NavLink } from 'react-router-dom';
import './Nav.css';

const Nav = () => {
  return ( 
    <nav className="grid_container grid_container_3">
		<div className="nav_input">
			<form>
			<input className="nav_search" placeholder="Search.." type="search"></input>
			<button className="button_search" type="submit">.</button>
			</form>
			<div className="list_container">
				<ul className="nav_list">
					<li><NavLink to="/profile" className="NavLink">Profile</NavLink></li>
					<li><NavLink to="/messages" className="NavLink">Messages</NavLink></li>
					<li><NavLink to="/news" className="NavLink">News</NavLink></li>
					<li><NavLink to="/music" className="NavLink">Music</NavLink></li>
					<li><NavLink to="/settings" className="NavLink">Settings</NavLink></li>
				</ul>
			</div>
		</div>
		
		<div className="nav_button"><button className="button_log_in-out">Log out</button></div>
	</nav>
	);
}


export default Nav;
