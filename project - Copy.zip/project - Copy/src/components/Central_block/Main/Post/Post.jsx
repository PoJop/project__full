import './Post.css';

const Post = (props) => {
  return ( 
    <div className="div_post">
      <img className="img_post" src="https://i.pinimg.com/originals/4d/af/2f/4daf2f183af331a8ba9a12bc2a458486.jpg" />
      <div className="post_message">
        {props.post}
      </div>
    </div>
	);
}


export default Post;