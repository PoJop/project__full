import './Main.css';
import Post from './Post/Post';

const Main = (props) => {

	
	  
    let postElements = props.postDate.map ( post =>  <Post post={post.post}/>);

	  
  return (
	<main className="grid_container grid_container_4">
		<div className="main_background">
			
			<form>
			<div className="main_textarea">
				<textarea className="textarea" placeholder="Your news.."></textarea>
			</div>
			<div className="button_container">
				<button className="button_textarea">Send</button>
			</div>
			</form>
		</div>
		<div className="container_post">
			{ postElements }
		</div>
	</main>
	);
}
export default Main;