import './Central_block.css';
import Main from "./Main/Main";
import Nav from "./Nav/Nav";
import Dialogs from './Dialogs/Dialogs';
import News from './News/News';
import Music from './Music/Music';
import Settings from './Settings/Settings';
import { Route } from 'react-router';
import { BrowserRouter } from 'react-router-dom';

const Central_block = (props) => {

	
	return (
		<BrowserRouter>
			<div className="grid_box grid_3">
				<Nav />
				<Route path="/profile" render={ () => <Main postDate={props.state.postDate}/>} />
				<Route path="/messages" render={ () => <Dialogs dialogsDate={props.state.dialogsDate} messageDate={props.state.messageDate}/>} />
				<Route path="/news" component={News} />
				<Route path="/music" component={Music} />
				<Route path="/settings" component={Settings} />
			</div>
		</BrowserRouter>
	);
}


export default Central_block;
