let state = {

  dialogsDate: [
    { id: 1, name: 'Oleg' },
    { id: 2, name: 'Nasty' },
    { id: 3, name: 'Karim' },
    { id: 4, name: 'Dima' }
  ],  
  messageDate: [
    { id: 1, message: 'Hi!' },
    { id: 1, message: 'Hi!' },
    { id: 1, message: 'Hi!' }
  ],
  postDate: [
    { id: 1, post: 'Hey' },
    { id: 2, post: 'How are you?' }
  ],
  statefriend: [
    { id: 1, name: 'Oleg' },
    { id: 2, name: 'Nasty' },
    { id: 3, name: 'Karim' },
    { id: 4, name: 'Dima' }
  ]
}

export default state;